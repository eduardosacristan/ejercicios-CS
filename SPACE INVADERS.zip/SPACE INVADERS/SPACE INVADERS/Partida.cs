﻿using System;

class Partida
{
    public void Lanzar()
    {
        Nave nave = new Nave();

        nave.MoverA(500, 600);
        nave.Dibujar();

        Enemigo[][] chungos = new Enemigo[3][];
        chungos[0] = new EnemigoA[10];
        chungos[1] = new EnemigoB[10];
        chungos[2] = new EnemigoC[10];

        for (byte i = 0; i < chungos[1].Length; i++)
        {
            chungos[0][i] = new EnemigoA(10 * i, 2);
            chungos[1][i] = new EnemigoB(10 * i, 5);
            chungos[2][i] = new EnemigoC(10 * i, 8);
        }
        
        Console.ReadLine();

        bool salir = false;
        do
        {
            Console.Clear();
            nave.Dibujar();
            
            for (byte i = 0; i < 3; i++)
            {
                for (byte j = 0; j < chungos[i].Length; j++)
                {
                    chungos[i][j].Dibujar();                    
                }
            }

            ConsoleKeyInfo tecla = Console.ReadKey();
            if (tecla.Key == ConsoleKey.LeftArrow) 
                nave.MoverIzquierda();
            else if (tecla.Key == ConsoleKey.RightArrow)
                nave.MoverDerecha();
            else if (tecla.Key == ConsoleKey.Escape)
                salir = true;
            
        }
        while (salir == false);
    }
}

