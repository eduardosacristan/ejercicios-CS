﻿using System;

class Nave : Sprite
{
    public Nave()
    {
        x = 500;
        y = 600;
        imagen = "/\\";
        Console.WriteLine("Creando Nave en posicion prefijada");
    }

    public Nave (int nuevaX, int nuevaY)
    {
        x = nuevaX;
        y = nuevaY;
        imagen = "/\\";
        Console.WriteLine("Creando nave en posicion indicada por el usuario");
    }

    public void MoverDerecha()
    {
        Console.ForegroundColor = ConsoleColor.White;
        x = x + 10;
    }
    public void MoverIzquierda()
    {
        Console.ForegroundColor = ConsoleColor.White;
        x = x - 10;
    }

    public override void Dibujar()
    {
        Console.SetCursorPosition(x, y);
        Console.ForegroundColor = ConsoleColor.White;
        Console.Write(imagen);
    }
}

