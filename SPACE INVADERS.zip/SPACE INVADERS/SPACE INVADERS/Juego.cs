﻿using System;


class Juego
{
    public void Lanzar()
    {
        Bienvenida bienvenida = new Bienvenida();
        Partida partida = new Partida();

        bool salir = false;
        do
        {
            bienvenida.Lanzar();
            salir = (bienvenida.GetSalir());
            
            if (salir == false)
            {
                Console.Clear();
                partida.Lanzar();
                
            }
            
        }
        while (salir == false);

    }

    public static void Main()
    {
        Juego juego = new Juego();
        juego.Lanzar();
    }
}

