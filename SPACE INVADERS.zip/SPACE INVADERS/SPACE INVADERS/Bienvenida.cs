﻿using System;

class Bienvenida
{
    public void Lanzar()
    {
        Console.WriteLine("Bienvenido a Console Invaders." + 
          " Pulse Intro para jugar o Esc para salir");
    }

    
    public bool GetSalir()
    {
        bool salir = false;
        ConsoleKeyInfo tecla = Console.ReadKey(); 
        if (tecla.Key == ConsoleKey.Escape) salir = true;
        else if (tecla.Key == ConsoleKey.Enter) salir = false;

        return salir;
    }
}

