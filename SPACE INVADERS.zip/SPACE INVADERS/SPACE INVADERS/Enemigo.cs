﻿using System;

class Enemigo : Sprite
{
    public Enemigo ()
    {
        x = 100;
        y = 80;
        imagen = "XX";
        Console.WriteLine("Creando nave enemiga en posicion prefijada");
    }

    public Enemigo (int nuevaX, int nuevaY)
    {
        x = nuevaX;
        y = nuevaY;
        imagen = "X";
        Console.WriteLine("Creando nave enemiga en posicion indicada por el usuario");
    }
    

}
class EnemigoA : Enemigo
{
    public EnemigoA(int posX, int posY) 
    {
        x = posX;
        y = posY;
        imagen = "}{";
        
    }
    public override void Dibujar()
    {
        Console.ForegroundColor = ConsoleColor.Green;
        base.Dibujar();
    }
}

class EnemigoB : Enemigo
{
    public EnemigoB(int posX, int posY) 
    {
        x = posX;
        y = posY;
        imagen = "$$";
    }
    public override void Dibujar()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        base.Dibujar();
    }


}
class EnemigoC : Enemigo
{
    public EnemigoC(int posX, int posY) 
    {
        x = posX;
        y = posY;
        imagen = "]["; 
    }
    public override void Dibujar()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        base.Dibujar();
    }
}


