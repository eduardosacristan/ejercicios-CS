﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ejercicio634
{
    class Bienvenida
    {
        public void Lanzar()
        {
            Console.WriteLine("Bienvenido a Space Invaders!");
            Console.WriteLine();
            Console.WriteLine("Pulse intro para jugar o ESC para salir");
            //Console.ReadLine();
        }

        public bool GetSalir()
        {
            ConsoleKeyInfo tecla = Console.ReadKey();
            return (tecla.Key == ConsoleKey.Escape);
        }
        
    }
}
