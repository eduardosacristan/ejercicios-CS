﻿using System;

namespace ejercicio634
{   
    class Nave : Sprite
    {
        public Nave()
        {
            x = 500;
            y = 600;
            imagen = "/\\";
        }
        public Nave(int xInicial, int yInicial)
        {
            x = xInicial;
            y = yInicial;
        }

            

        public void MoverDerecha() 
        {
            x = x + 5;
        }  
        
        public void MoverIzquierda() 
        { 
            x = x - 5; 
        }


    }
}
