﻿using System;

namespace ejercicio634
{
    class Partida
    {
        public void Lanzar()
        {
            /*Console.WriteLine("Esta sería la pantalla de juego");
            Console.WriteLine();
            Console.WriteLine("Pulse intro para salir");
            Console.ReadLine();*/

            Console.Clear();
            Nave spaceship = new Nave(500,500);
            Enemigo alien = new Enemigo(1000, 80);
            
            spaceship.Mover(500, 600);
            spaceship.Dibujar();
            alien.Mover(1000, 80);
            alien.Dibujar();
            bool salir = false;
            
            do
            {
                spaceship.Dibujar();
                alien.Dibujar();
                ConsoleKeyInfo tecla2 = Console.ReadKey();
                if (tecla2.Key == ConsoleKey.LeftArrow) spaceship.MoverIzquierda();
                else if (tecla2.Key == ConsoleKey.RightArrow) spaceship.MoverDerecha();
                else if (tecla2.Key == ConsoleKey.Escape) salir = true;
                Console.Clear();
                
            }
            while (salir == false);
        }
    }
}
