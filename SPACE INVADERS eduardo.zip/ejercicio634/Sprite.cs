﻿using System;

namespace ejercicio634
{
    class Sprite
    {
        protected int x;
        protected int y;
        protected string imagen = "][";

        public void Mover(int nuevaX, int nuevaY)
        {
            x = nuevaX / 12;
            y = nuevaY / 30;
        }
        public void Dibujar()
        {
            Console.SetCursorPosition(x, y);
            Console.WriteLine(imagen);
        }
    }
}
