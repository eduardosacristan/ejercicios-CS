﻿using System;


namespace ejercicio634
{
    class Enemigo : Sprite
    {
        public Enemigo(int xx, int yy)
        {
            x = xx;
            y = yy;
            imagen = "-v-";
        }
        public Enemigo()
        {
            x = 100;
            y = 80;
        }
        
    }
}
