﻿using System;

namespace ejercicio634
{
    class Juego
    {
        public void Lanzar()
        {
            bool salir;
            Bienvenida vb = new Bienvenida();
            Partida pt = new Partida();
            //do
            //{
                vb.Lanzar();
                salir = vb.GetSalir();
                if (!salir)
                {
                    pt.Lanzar();
                }
            //}
            //while (!salir);
        }

        public static void Main()
        {
            Juego j1 = new Juego();
            j1.Lanzar();
        }
    }
}
